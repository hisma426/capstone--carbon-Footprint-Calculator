# Status Report

#### Your name

Noa Kligfeld and Ben Fisher

#### Your section leader's name

Jonny Zhang and Albert Zhu

#### Project title

5 (foot)Steps to Reduce your Carbon Footprint

***

Short answers for the below questions suffice. If you want to alter your plan for your project (and obtain approval for the same), be sure to email your section leader directly!

#### What have you done for your project so far?

we've done the environmental research to gather rough estimates of how many pounds of carbon are produced by different activities
We've created databases that store the actions with the corresponding pounds of carbon
We set up a register page with appropriate input checkers
a login page with appropriate input checkers
and a calculate page that is not full yet.
We've outlined all of our functions and written pseudocode for all of them.
We've divided up the work evenly working off of our strengths and interests.



#### What have you not done for your project yet?
BASIC MUSTS
styles.css ben
layout.html ben
welcome.html ben
survey pseudocode ben
apology/error checker ben

log.html and its python noa
history.html and its python noa
verify email is valid noa
calculate.html and its python noa
calculated.html noa

COOL ADD-ONS
send daily emails to remind you to log your carbon
graphs to better visualize your history
popups with carbon facts
change password/"forgot password"

COOLER ADD-ONS
point/reward system
social media-type platform


#### What problems, if any, have you encountered?

Trying to determine how to calculate carbon footprint in
a way which is as precise as possible while also simplified and
user-friendly.
