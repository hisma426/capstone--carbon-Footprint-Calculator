const prevBtn = document.querySelector('.prev-btn');
const nextBtn = document.querySelector('.next-btn');
const carouselSlide = document.querySelector('.carousel-slide');

let counter = 0;
const size = carouselSlide.clientWidth;

prevBtn.addEventListener('click', () => {
    counter--;
    if (counter < 0) {
        counter = 2; // Set counter to the last image index
    }
    carouselSlide.style.transition = 'transform 0.5s ease-in-out';
    carouselSlide.style.transform = `translateX(${-size * counter}px)`;
});

nextBtn.addEventListener('click', () => {
    counter++;
    if (counter > 2) {
        counter = 0; // Set counter to the first image index
    }
    carouselSlide.style.transition = 'transform 0.5s ease-in-out';
    carouselSlide.style.transform = `translateX(${-size * counter}px)`;
});